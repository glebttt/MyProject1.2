package code.algorithms.Solvers;

public class AnotherFunction implements Function {

    public double evaluation(double y0, double t){
        return y0 + Math.cos(t);
    }
}
