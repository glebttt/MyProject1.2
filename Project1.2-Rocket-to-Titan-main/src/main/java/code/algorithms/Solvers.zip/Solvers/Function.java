package code.algorithms.Solvers;

public interface Function {

    double evaluation(double y0, double t);


}
